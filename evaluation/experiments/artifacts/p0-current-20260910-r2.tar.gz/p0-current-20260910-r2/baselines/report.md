# Agent Evaluation v1: Deterministic Retrieval Baselines

Run: baselines

One original-query engine request per applicable case and baseline; binary expected_sources labels.
top_k=10 limits returned chunks. Sources collapse in first-occurrence order; no refill requests.
R@K/nDCG@K use the deduplicated source ranking; MRR uses that entire returned ranking.
Ranking means exclude errors and no_retrieval. Successful empty rankings count as zero.
Latency includes attempted requests, including failures; setup is separate in run_metadata.json.
Every metric denominator is saved in summary.json.

## Overall

| Method | Evaluated / applicable | N/A | Errors | R@1 | R@3 | R@5 | R@10 | MRR | nDCG@10 | Latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bm25 | 34 / 34 | 6 | 0 | 0.2142 | 0.2480 | 0.2980 | 0.3039 | 0.3211 | 0.2872 | 0.2197 |
| semantic | 34 / 34 | 6 | 0 | 0.5613 | 0.7789 | 0.8113 | 0.8279 | 0.9559 | 0.8464 | 79.2857 |
| hybrid | 34 / 34 | 6 | 0 | 0.5848 | 0.7794 | 0.8235 | 0.8402 | 0.9471 | 0.8545 | 75.6681 |
| hybrid_rerank | 34 / 34 | 6 | 0 | 0.5466 | 0.8010 | 0.8510 | 0.8730 | 0.9412 | 0.8687 | 2839.3848 |

## direct_read

| Method | Evaluated / applicable | N/A | Errors | R@1 | R@3 | R@5 | R@10 | MRR | nDCG@10 | Latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bm25 | 6 / 6 | 0 | 0 | 0.1667 | 0.1667 | 0.1667 | 0.1667 | 0.1667 | 0.1667 | 0.1252 |
| semantic | 6 / 6 | 0 | 0 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 81.6959 |
| hybrid | 6 / 6 | 0 | 0 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 72.3563 |
| hybrid_rerank | 6 / 6 | 0 | 0 | 0.8333 | 1.0000 | 1.0000 | 1.0000 | 0.9167 | 0.9385 | 2855.7416 |

## exact_lookup

| Method | Evaluated / applicable | N/A | Errors | R@1 | R@3 | R@5 | R@10 | MRR | nDCG@10 | Latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bm25 | 6 / 6 | 0 | 0 | 0.7833 | 0.9333 | 0.9667 | 0.9667 | 1.0000 | 0.9648 | 0.2177 |
| semantic | 6 / 6 | 0 | 0 | 0.6167 | 0.8500 | 0.8833 | 0.8833 | 0.9167 | 0.8521 | 82.2459 |
| hybrid | 6 / 6 | 0 | 0 | 0.7833 | 0.9333 | 1.0000 | 1.0000 | 1.0000 | 0.9866 | 74.7259 |
| hybrid_rerank | 6 / 6 | 0 | 0 | 0.7833 | 0.9333 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 2889.5568 |

## exploratory_retrieval

| Method | Evaluated / applicable | N/A | Errors | R@1 | R@3 | R@5 | R@10 | MRR | nDCG@10 | Latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bm25 | 10 / 10 | 0 | 0 | 0.0583 | 0.0833 | 0.1333 | 0.1533 | 0.2667 | 0.1546 | 0.3235 |
| semantic | 10 / 10 | 0 | 0 | 0.2850 | 0.5950 | 0.6517 | 0.6883 | 1.0000 | 0.7535 | 76.4723 |
| hybrid | 10 / 10 | 0 | 0 | 0.2650 | 0.5467 | 0.6233 | 0.6600 | 0.9200 | 0.7006 | 77.0504 |
| hybrid_rerank | 10 / 10 | 0 | 0 | 0.2850 | 0.5700 | 0.6467 | 0.6883 | 1.0000 | 0.7524 | 2853.9944 |

## knowledge_qa

| Method | Evaluated / applicable | N/A | Errors | R@1 | R@3 | R@5 | R@10 | MRR | nDCG@10 | Latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bm25 | 6 / 6 | 0 | 0 | 0.1667 | 0.1667 | 0.3333 | 0.3333 | 0.2083 | 0.2384 | 0.3474 |
| semantic | 6 / 6 | 0 | 0 | 0.7500 | 0.9167 | 0.9167 | 0.9167 | 1.0000 | 0.9355 | 80.7595 |
| hybrid | 6 / 6 | 0 | 0 | 0.7500 | 0.9167 | 0.9167 | 0.9167 | 1.0000 | 0.9355 | 76.4775 |
| hybrid_rerank | 6 / 6 | 0 | 0 | 0.7500 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 2783.4463 |

## no_retrieval

| Method | Evaluated / applicable | N/A | Errors | R@1 | R@3 | R@5 | R@10 | MRR | nDCG@10 | Latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bm25 | 0 / 0 | 6 | 0 | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| semantic | 0 / 0 | 6 | 0 | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| hybrid | 0 / 0 | 6 | 0 | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| hybrid_rerank | 0 / 0 | 6 | 0 | N/A | N/A | N/A | N/A | N/A | N/A | N/A |

## semantic_discovery

| Method | Evaluated / applicable | N/A | Errors | R@1 | R@3 | R@5 | R@10 | MRR | nDCG@10 | Latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bm25 | 6 / 6 | 0 | 0 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0157 |
| semantic | 6 / 6 | 0 | 0 | 0.3389 | 0.6556 | 0.7111 | 0.7444 | 0.8333 | 0.7525 | 77.1306 |
| hybrid | 6 / 6 | 0 | 0 | 0.3389 | 0.6556 | 0.7111 | 0.7444 | 0.8333 | 0.7525 | 76.8087 |
| hybrid_rerank | 6 / 6 | 0 | 0 | 0.2556 | 0.6556 | 0.7444 | 0.8000 | 0.7500 | 0.7300 | 2804.4454 |

## Comparison with Agent outcomes

Baseline source recall can be compared with Agent trajectory unique-source recall on identical cases,
snapshot and defined denominators, with the one-request versus accumulated-evidence budget stated.
Agent task success also checks tool/read/turn constraints; it is not a baseline ranking metric.
MRR/nDCG apply only to baseline rankings. No synthetic Agent ranking or baseline task success is created.
Agent tool calls, turns, token usage and answer quality are not inferred from these retrieval results.

## Retrieval errors

No retrieval errors.
