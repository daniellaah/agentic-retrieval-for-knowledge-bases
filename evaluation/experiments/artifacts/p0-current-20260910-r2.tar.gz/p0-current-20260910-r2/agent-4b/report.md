# Agent Evaluation v1

Run: agent-4b

Source coverage and tool behavior only; answer quality is not graded.

| Metric | Value |
| --- | ---: |
| total_cases | 40 |
| total_trials | 120 |
| task_success_rate | 0.7750 |
| average_source_recall | 0.8672 |
| average_tool_calls | 3.1000 |
| average_turns | 3.6250 |
| max_turn_failure_rate | 0.1000 |
| unnecessary_retrieval_rate | 0 |
| missing_trace_trials | 0 |

Recall excludes no-retrieval and unavailable traces. Unnecessary retrieval uses only
observed no-retrieval trials. Other behavior means use observed traces.
Exact denominators are recorded in summary.json.

## Task types

| Task type | Trials | Success rate | Mean recall |
| --- | ---: | ---: | ---: |
| direct_read | 18 | 1.0000 | 1.0000 |
| exact_lookup | 18 | 0.8333 | 0.9000 |
| exploratory_retrieval | 30 | 0.4000 | 0.7817 |
| knowledge_qa | 18 | 0.6667 | 0.9167 |
| no_retrieval | 18 | 1.0000 | undefined |
| semantic_discovery | 18 | 1.0000 | 0.7944 |

## Tool requests

| Name | Count |
| --- | ---: |
| match | 18 |
| read | 192 |
| search | 162 |

## Stop reasons

| Name | Count |
| --- | ---: |
| error | 6 |
| final | 102 |
| max_turns | 12 |
| other | 0 |
| unavailable | 0 |

## Failed trials

### exact_001 / trial 0

| Field | Value |
| --- | --- |
| query | 找出知识库正文中包含精确文本“RAG”的所有笔记，按大小写一致的子串匹配，列出文件名。 |
| task_type | exact_lookup |
| expected_sources | 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 33_graph_search_strategies.md, 37_multimodal_evidence_retrieval.md, 40_query_planning_and_compression.md |
| retrieved_sources | 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md |
| tool_sequence | match |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |

### exact_001 / trial 1

| Field | Value |
| --- | --- |
| query | 找出知识库正文中包含精确文本“RAG”的所有笔记，按大小写一致的子串匹配，列出文件名。 |
| task_type | exact_lookup |
| expected_sources | 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 33_graph_search_strategies.md, 37_multimodal_evidence_retrieval.md, 40_query_planning_and_compression.md |
| retrieved_sources | 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md |
| tool_sequence | match |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |

### exact_001 / trial 2

| Field | Value |
| --- | --- |
| query | 找出知识库正文中包含精确文本“RAG”的所有笔记，按大小写一致的子串匹配，列出文件名。 |
| task_type | exact_lookup |
| expected_sources | 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 33_graph_search_strategies.md, 37_multimodal_evidence_retrieval.md, 40_query_planning_and_compression.md |
| retrieved_sources | 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md |
| tool_sequence | match |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |

### explore_001 / trial 0

| Field | Value |
| --- | --- |
| query | 我要写一篇 Agent Memory 的文章，找相关素材，并打开至少两篇有价值的笔记核对要点。 |
| task_type | exploratory_retrieval |
| expected_sources | 06_context_compaction.md, 07_long_running_harnesses.md, 34_agent_memory_lifecycle.md |
| retrieved_sources | 34_agent_memory_lifecycle.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, search, read, search, search |
| stop_reason | max_turns |
| failure_reasons | not_final, source_recall_below_threshold, insufficient_read_sources |

### explore_001 / trial 1

| Field | Value |
| --- | --- |
| query | 我要写一篇 Agent Memory 的文章，找相关素材，并打开至少两篇有价值的笔记核对要点。 |
| task_type | exploratory_retrieval |
| expected_sources | 06_context_compaction.md, 07_long_running_harnesses.md, 34_agent_memory_lifecycle.md |
| retrieved_sources | 34_agent_memory_lifecycle.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, search, read, search, search |
| stop_reason | max_turns |
| failure_reasons | not_final, source_recall_below_threshold, insufficient_read_sources |

### explore_001 / trial 2

| Field | Value |
| --- | --- |
| query | 我要写一篇 Agent Memory 的文章，找相关素材，并打开至少两篇有价值的笔记核对要点。 |
| task_type | exploratory_retrieval |
| expected_sources | 06_context_compaction.md, 07_long_running_harnesses.md, 34_agent_memory_lifecycle.md |
| retrieved_sources | 34_agent_memory_lifecycle.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, search, read, search, search |
| stop_reason | max_turns |
| failure_reasons | not_final, source_recall_below_threshold, insufficient_read_sources |

### explore_002 / trial 0

| Field | Value |
| --- | --- |
| query | 整理知识库里关于 Agentic Retrieval 的材料，涵盖工具接口、候选检索和继续读取原文，并打开至少两篇候选。 |
| task_type | exploratory_retrieval |
| expected_sources | 01_workflows_and_agents.md, 02_tool_interface_design.md, 13_hybrid_rank_fusion.md, 14_cross_encoder_reranking.md, 40_query_planning_and_compression.md |
| retrieved_sources | 02_tool_interface_design.md, 05_agent_skills.md, 06_context_compaction.md, 07_long_running_harnesses.md, 12_contextual_retrieval.md, 22_process_supervision.md, 28_graph_retrieval.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 34_agent_memory_lifecycle.md, 36_prompt_injection_and_monitors.md, 37_multimodal_evidence_retrieval.md, 38_agent_evaluation_and_observability.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, read, read, read, read, search |
| stop_reason | max_turns |
| failure_reasons | not_final, source_recall_below_threshold |

### explore_002 / trial 1

| Field | Value |
| --- | --- |
| query | 整理知识库里关于 Agentic Retrieval 的材料，涵盖工具接口、候选检索和继续读取原文，并打开至少两篇候选。 |
| task_type | exploratory_retrieval |
| expected_sources | 01_workflows_and_agents.md, 02_tool_interface_design.md, 13_hybrid_rank_fusion.md, 14_cross_encoder_reranking.md, 40_query_planning_and_compression.md |
| retrieved_sources | 02_tool_interface_design.md, 05_agent_skills.md, 06_context_compaction.md, 07_long_running_harnesses.md, 12_contextual_retrieval.md, 22_process_supervision.md, 28_graph_retrieval.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 34_agent_memory_lifecycle.md, 36_prompt_injection_and_monitors.md, 37_multimodal_evidence_retrieval.md, 38_agent_evaluation_and_observability.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, read, read, read, read, search |
| stop_reason | max_turns |
| failure_reasons | not_final, source_recall_below_threshold |

### explore_002 / trial 2

| Field | Value |
| --- | --- |
| query | 整理知识库里关于 Agentic Retrieval 的材料，涵盖工具接口、候选检索和继续读取原文，并打开至少两篇候选。 |
| task_type | exploratory_retrieval |
| expected_sources | 01_workflows_and_agents.md, 02_tool_interface_design.md, 13_hybrid_rank_fusion.md, 14_cross_encoder_reranking.md, 40_query_planning_and_compression.md |
| retrieved_sources | 02_tool_interface_design.md, 05_agent_skills.md, 06_context_compaction.md, 07_long_running_harnesses.md, 12_contextual_retrieval.md, 22_process_supervision.md, 28_graph_retrieval.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 34_agent_memory_lifecycle.md, 36_prompt_injection_and_monitors.md, 37_multimodal_evidence_retrieval.md, 38_agent_evaluation_and_observability.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, read, read, read, read, search |
| stop_reason | max_turns |
| failure_reasons | not_final, source_recall_below_threshold |

### explore_004 / trial 0

| Field | Value |
| --- | --- |
| query | 我要排查文档找对了但回答仍错误的问题，先收集切分、结构、上下文和多模态证据相关材料。 |
| task_type | exploratory_retrieval |
| expected_sources | 12_contextual_retrieval.md, 15_chunk_boundaries.md, 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md, 40_query_planning_and_compression.md |
| retrieved_sources | 12_contextual_retrieval.md, 15_chunk_boundaries.md, 26_simpleqa_factuality.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, read, read, read, read |
| stop_reason | max_turns |
| failure_reasons | not_final |

### explore_004 / trial 1

| Field | Value |
| --- | --- |
| query | 我要排查文档找对了但回答仍错误的问题，先收集切分、结构、上下文和多模态证据相关材料。 |
| task_type | exploratory_retrieval |
| expected_sources | 12_contextual_retrieval.md, 15_chunk_boundaries.md, 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md, 40_query_planning_and_compression.md |
| retrieved_sources | 12_contextual_retrieval.md, 15_chunk_boundaries.md, 26_simpleqa_factuality.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, read, read, read, read |
| stop_reason | max_turns |
| failure_reasons | not_final |

### explore_004 / trial 2

| Field | Value |
| --- | --- |
| query | 我要排查文档找对了但回答仍错误的问题，先收集切分、结构、上下文和多模态证据相关材料。 |
| task_type | exploratory_retrieval |
| expected_sources | 12_contextual_retrieval.md, 15_chunk_boundaries.md, 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md, 40_query_planning_and_compression.md |
| retrieved_sources | 12_contextual_retrieval.md, 15_chunk_boundaries.md, 26_simpleqa_factuality.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, read, read, read, read |
| stop_reason | max_turns |
| failure_reasons | not_final |

### explore_006 / trial 0

| Field | Value |
| --- | --- |
| query | 准备一篇降低助手上下文开销的文章，搜集按需加载、代码处理结果、摘要和缓存这些不同办法的素材。 |
| task_type | exploratory_retrieval |
| expected_sources | 03_dynamic_tool_discovery.md, 04_code_execution_for_tools.md, 05_agent_skills.md, 06_context_compaction.md, 11_prompt_caching.md, 40_query_planning_and_compression.md |
| retrieved_sources | 03_dynamic_tool_discovery.md, 04_code_execution_for_tools.md, 06_context_compaction.md, 11_prompt_caching.md, 12_contextual_retrieval.md, 35_llm_serving_and_kv_cache.md, 36_prompt_injection_and_monitors.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, read, read |
| stop_reason | error |
| failure_reasons | not_final |
| runtime error | ValueError: Character range is outside the current document body. |

### explore_006 / trial 1

| Field | Value |
| --- | --- |
| query | 准备一篇降低助手上下文开销的文章，搜集按需加载、代码处理结果、摘要和缓存这些不同办法的素材。 |
| task_type | exploratory_retrieval |
| expected_sources | 03_dynamic_tool_discovery.md, 04_code_execution_for_tools.md, 05_agent_skills.md, 06_context_compaction.md, 11_prompt_caching.md, 40_query_planning_and_compression.md |
| retrieved_sources | 03_dynamic_tool_discovery.md, 04_code_execution_for_tools.md, 06_context_compaction.md, 11_prompt_caching.md, 12_contextual_retrieval.md, 35_llm_serving_and_kv_cache.md, 36_prompt_injection_and_monitors.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, read, read |
| stop_reason | error |
| failure_reasons | not_final |
| runtime error | ValueError: Character range is outside the current document body. |

### explore_006 / trial 2

| Field | Value |
| --- | --- |
| query | 准备一篇降低助手上下文开销的文章，搜集按需加载、代码处理结果、摘要和缓存这些不同办法的素材。 |
| task_type | exploratory_retrieval |
| expected_sources | 03_dynamic_tool_discovery.md, 04_code_execution_for_tools.md, 05_agent_skills.md, 06_context_compaction.md, 11_prompt_caching.md, 40_query_planning_and_compression.md |
| retrieved_sources | 03_dynamic_tool_discovery.md, 04_code_execution_for_tools.md, 06_context_compaction.md, 11_prompt_caching.md, 12_contextual_retrieval.md, 35_llm_serving_and_kv_cache.md, 36_prompt_injection_and_monitors.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, read, read |
| stop_reason | error |
| failure_reasons | not_final |
| runtime error | ValueError: Character range is outside the current document body. |

### explore_007 / trial 0

| Field | Value |
| --- | --- |
| query | 我想比较多 Agent 协作与单个 Agent 的取舍，找自主性、协调成本、交接和共享记忆相关材料，打开至少两篇。 |
| task_type | exploratory_retrieval |
| expected_sources | 01_workflows_and_agents.md, 07_long_running_harnesses.md, 31_multi_agent_coordination.md, 34_agent_memory_lifecycle.md |
| retrieved_sources | 31_multi_agent_coordination.md, 34_agent_memory_lifecycle.md |
| tool_sequence | search, read, read |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |

### explore_007 / trial 1

| Field | Value |
| --- | --- |
| query | 我想比较多 Agent 协作与单个 Agent 的取舍，找自主性、协调成本、交接和共享记忆相关材料，打开至少两篇。 |
| task_type | exploratory_retrieval |
| expected_sources | 01_workflows_and_agents.md, 07_long_running_harnesses.md, 31_multi_agent_coordination.md, 34_agent_memory_lifecycle.md |
| retrieved_sources | 31_multi_agent_coordination.md, 34_agent_memory_lifecycle.md |
| tool_sequence | search, read, read |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |

### explore_007 / trial 2

| Field | Value |
| --- | --- |
| query | 我想比较多 Agent 协作与单个 Agent 的取舍，找自主性、协调成本、交接和共享记忆相关材料，打开至少两篇。 |
| task_type | exploratory_retrieval |
| expected_sources | 01_workflows_and_agents.md, 07_long_running_harnesses.md, 31_multi_agent_coordination.md, 34_agent_memory_lifecycle.md |
| retrieved_sources | 31_multi_agent_coordination.md, 34_agent_memory_lifecycle.md |
| tool_sequence | search, read, read |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |

### explore_010 / trial 0

| Field | Value |
| --- | --- |
| query | 帮我规划一份“检索还是训练”阅读清单，涵盖外部知识、参数高效微调、偏好训练和训练数据质量。 |
| task_type | exploratory_retrieval |
| expected_sources | 19_parameter_efficient_tuning.md, 20_direct_preference_optimization.md, 30_retrieval_and_fine_tuning.md, 39_synthetic_data_quality.md |
| retrieved_sources | 17_embedding_quantization.md, 19_parameter_efficient_tuning.md, 20_direct_preference_optimization.md, 22_process_supervision.md, 23_weak_to_strong_generalization.md, 24_deliberative_alignment.md, 25_hallucination_incentives.md, 26_simpleqa_factuality.md, 28_graph_retrieval.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 33_graph_search_strategies.md, 34_agent_memory_lifecycle.md, 35_llm_serving_and_kv_cache.md, 37_multimodal_evidence_retrieval.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, search, read, read, read |
| stop_reason | max_turns |
| failure_reasons | not_final |

### explore_010 / trial 1

| Field | Value |
| --- | --- |
| query | 帮我规划一份“检索还是训练”阅读清单，涵盖外部知识、参数高效微调、偏好训练和训练数据质量。 |
| task_type | exploratory_retrieval |
| expected_sources | 19_parameter_efficient_tuning.md, 20_direct_preference_optimization.md, 30_retrieval_and_fine_tuning.md, 39_synthetic_data_quality.md |
| retrieved_sources | 17_embedding_quantization.md, 19_parameter_efficient_tuning.md, 20_direct_preference_optimization.md, 22_process_supervision.md, 23_weak_to_strong_generalization.md, 24_deliberative_alignment.md, 25_hallucination_incentives.md, 26_simpleqa_factuality.md, 28_graph_retrieval.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 33_graph_search_strategies.md, 34_agent_memory_lifecycle.md, 35_llm_serving_and_kv_cache.md, 37_multimodal_evidence_retrieval.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, search, read, read, read |
| stop_reason | max_turns |
| failure_reasons | not_final |

### explore_010 / trial 2

| Field | Value |
| --- | --- |
| query | 帮我规划一份“检索还是训练”阅读清单，涵盖外部知识、参数高效微调、偏好训练和训练数据质量。 |
| task_type | exploratory_retrieval |
| expected_sources | 19_parameter_efficient_tuning.md, 20_direct_preference_optimization.md, 30_retrieval_and_fine_tuning.md, 39_synthetic_data_quality.md |
| retrieved_sources | 17_embedding_quantization.md, 19_parameter_efficient_tuning.md, 20_direct_preference_optimization.md, 22_process_supervision.md, 23_weak_to_strong_generalization.md, 24_deliberative_alignment.md, 25_hallucination_incentives.md, 26_simpleqa_factuality.md, 28_graph_retrieval.md, 30_retrieval_and_fine_tuning.md, 32_document_ingestion_and_structure.md, 33_graph_search_strategies.md, 34_agent_memory_lifecycle.md, 35_llm_serving_and_kv_cache.md, 37_multimodal_evidence_retrieval.md, 39_synthetic_data_quality.md, 40_query_planning_and_compression.md |
| tool_sequence | search, search, search, search, search, read, read, read |
| stop_reason | max_turns |
| failure_reasons | not_final |

### qa_004 / trial 0

| Field | Value |
| --- | --- |
| query | 知识库怎样区分 pass-at-k 与每次都成功，它们对报告失败有什么要求？ |
| task_type | knowledge_qa |
| expected_sources | 27_agent_trial_reliability.md |
| retrieved_sources | 21_speculative_decoding.md, 27_agent_trial_reliability.md, 30_retrieval_and_fine_tuning.md |
| tool_sequence | search, read |
| stop_reason | error |
| failure_reasons | not_final |
| runtime error | ValueError: document_id must be a lowercase SHA-256 hex digest. |

### qa_004 / trial 1

| Field | Value |
| --- | --- |
| query | 知识库怎样区分 pass-at-k 与每次都成功，它们对报告失败有什么要求？ |
| task_type | knowledge_qa |
| expected_sources | 27_agent_trial_reliability.md |
| retrieved_sources | 21_speculative_decoding.md, 27_agent_trial_reliability.md, 30_retrieval_and_fine_tuning.md |
| tool_sequence | search, read |
| stop_reason | error |
| failure_reasons | not_final |
| runtime error | ValueError: document_id must be a lowercase SHA-256 hex digest. |

### qa_004 / trial 2

| Field | Value |
| --- | --- |
| query | 知识库怎样区分 pass-at-k 与每次都成功，它们对报告失败有什么要求？ |
| task_type | knowledge_qa |
| expected_sources | 27_agent_trial_reliability.md |
| retrieved_sources | 21_speculative_decoding.md, 27_agent_trial_reliability.md, 30_retrieval_and_fine_tuning.md |
| tool_sequence | search, read |
| stop_reason | error |
| failure_reasons | not_final |
| runtime error | ValueError: document_id must be a lowercase SHA-256 hex digest. |

### qa_006 / trial 0

| Field | Value |
| --- | --- |
| query | 根据知识库，表格页面检索正确以后，为什么仍可能把错误证据交给生成器？ |
| task_type | knowledge_qa |
| expected_sources | 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md |
| retrieved_sources | 04_code_execution_for_tools.md, 37_multimodal_evidence_retrieval.md |
| tool_sequence | search, read, read, read, read |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |

### qa_006 / trial 1

| Field | Value |
| --- | --- |
| query | 根据知识库，表格页面检索正确以后，为什么仍可能把错误证据交给生成器？ |
| task_type | knowledge_qa |
| expected_sources | 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md |
| retrieved_sources | 04_code_execution_for_tools.md, 37_multimodal_evidence_retrieval.md |
| tool_sequence | search, read, read, read, read |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |

### qa_006 / trial 2

| Field | Value |
| --- | --- |
| query | 根据知识库，表格页面检索正确以后，为什么仍可能把错误证据交给生成器？ |
| task_type | knowledge_qa |
| expected_sources | 32_document_ingestion_and_structure.md, 37_multimodal_evidence_retrieval.md |
| retrieved_sources | 04_code_execution_for_tools.md, 37_multimodal_evidence_retrieval.md |
| tool_sequence | search, read, read, read, read |
| stop_reason | final |
| failure_reasons | source_recall_below_threshold |
