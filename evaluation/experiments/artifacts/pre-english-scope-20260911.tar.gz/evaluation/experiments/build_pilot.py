"""Build an explicitly assistant-authored, provisional 60-query development set.

Uses the 40 existing authored example notes plus 18 clearly synthetic bridge /
policy / distractor documents. It is neither user traffic nor human-reviewed gold.
The output must be a new directory; do not overwrite review work.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil

from arkb.knowledge.documents import load_notes
from arkb.evaluation.v2 import SCHEMA, load_dataset, dataset_report


# Each seed contains an information need, explicit supporting sections, and a
# draft answer criterion. Shared topics keep the same family across task types.
SEMANTIC = [
('control','我想让助手根据刚获得的信息决定下一步，而不是执行写死的步骤。找一篇能说明这种区别的笔记。',[1],'模型随新信息选择下一步动作，预定义步骤属于 workflow。'),
('interfaces','工具名字相近、参数含糊，模型经常选错操作。找讨论接口该如何设计的材料。',[2],'工具职责、命名、参数与输出都应明确。'),
('tool_loading','助手启动时加载数百个操作的说明，占掉很多上下文。找能够减少这类占用的方案。',[3],'按需发现工具，再加载对应 schema。'),
('aggregation','大量中间数据只需要求和与筛选，不值得让模型逐行阅读。哪里讨论了这种处理方式？',[4],'在执行环境中处理数据，只返回摘要和必要证据。'),
('skill_loading','有哪些材料介绍只先展示操作手册的简介，等用到时再展开详细步骤？',[5],'技能逐层加载入口、详细说明与附加资源。'),
('handoff','一次任务跨越多个上下文窗口，重启后容易忘记未解决的问题。找说明摘要需要保留什么的笔记。',[6],'保留决策、未解决问题和依赖。'),
('verification','上一轮助手说任务做完了，下一轮应该凭什么检查这个说法？找相关笔记。',[7],'用工作应用的实际检查核对完成状态，保留未完成工作。'),
('intermediate_reasoning','我想在工具返回结果之后安排一个专门的思考步骤。找讨论这类设计作用和边界的资料。',[8],'思考步骤用于复核新信息，本身不获取外部证据或修改环境。'),
('isolation','只限制助手写文件，是否已经限制了它访问外部服务？找能区分这些边界的材料。',[9],'文件系统和网络限制是不同的边界。'),
('protocol','每个 AI 应用都要给相同数据源重写连接器。找试图统一这层接口的笔记。',[10],'MCP 用客户端与服务端统一能力连接边界。'),
('cache','多次请求都带相同长说明，我想复用其处理计算。找讨论这种优化及其适用条件的笔记。',[11],'后续请求共享重复 prompt 内容时，可以复用对应处理计算。'),
('graph','一条资料中的实体指向另一条资料，希望沿关系收集证据。哪些笔记介绍了这种能力及其风险？',[28],'图关系可连接多个片段，模型抽取的实体和关系仍需质量检查。'),
]
EXPLORE = [
('control','准备一份阅读清单，分别解释谁来决定下一步动作，以及工具结果到达后如何复核信息。',[1,8],'分别覆盖控制流自主性与工具调用间的复核。'),
('interfaces','我要设计外部能力集成，收集连接协议的职责划分和模型工具接口的设计要点。',[10,2],'覆盖客户端/服务端边界和工具名称参数输出设计。'),
('tool_loading','比较大工具目录和任务手册怎样按需加载，分别给出相关笔记。',[3,5],'区分工具发现/schema 加载与技能说明分层加载。'),
('aggregation','我需要降低处理重复内容和中间数据的费用，分别找计算缓存与代码聚合的资料。',[11,4],'缓存重复 prompt 计算；代码处理工具返回的数据。'),
('handoff','准备一份跨会话任务交接指南，收集摘要保留内容与下一轮工作检查流程。',[6,7],'摘要保存约束与未完成事项；新会话检查交接产物并验证工作。'),
('verification','评估一个助手是否可靠，找关于实际完成检查与重复尝试统计的两类资料。',[7,27],'不能只信完成声明；重复尝试中的失败应保留。'),
('vectors','我想比较两种压缩向量的方法，请收集分别减少坐标数和降低每个坐标精度的材料。',[16,17],'截短维度与量化数值精度是不同操作。'),
('benchmark_scope','做模型选型时，我需要区分 embedding 任务覆盖与短事实问答的评测边界，请找两类材料。',[18,26],'embedding 多任务成绩与短事实问答不能替代目标应用测量。'),
('training','准备模型适配资料，分别说明小参数增量如何部署，以及偏好样本如何影响学习。',[19,20],'adapter 依赖基座；DPO 的偏好对质量决定学习信号。'),
('cache','做生成服务优化阅读清单，区分重复输入计算复用和草稿 token 验证两种办法。',[11,21],'prompt 缓存与 speculative decoding 优化不同阶段。'),
('oversight','比较监督信号来自中间推理步骤还是较弱模型的两种研究设定，请找对应材料并说明外推限制。',[22,23],'区分过程反馈和弱监督，不能直接外推到所有领域或未来超强模型。'),
('structure','收集两种避免片段脱离语境的方法：改切分边界和为片段补局部背景。',[15,12],'边界保留完整含义；补充片段特定背景应对照原文。'),
]
QA = [
('context','给每个检索片段都加相同的文档摘要，是否符合笔记对补充背景的建议？',[12],'应补片段特定的背景，而不是统一通用摘要。'),
('fusion','融合词法和向量检索时，为什么不能把融合后的分数当成余弦相似度？',[13],'RRF 以排名位置融合，结果是新的排序分数。'),
('candidate_limit','重排候选已经包含了相关片段之外的材料，它能否把完全没召回的证据变出来？',[14],'重排只能重排候选集，不能恢复不在候选中的证据。'),
('structure','一个切片符合长度上限，却把定义与后续条件分开，为什么仍需调整？',[15],'长度约束不保证语义完整，应保留限定条件的邻近上下文。'),
('vectors','对于需要单位向量的相似度计算，把已经归一化的向量截短后还要做什么？',[16],'在相似度要求单位长度时，截短后重新归一化。'),
('quantization','标量量化的桶边界受什么影响？它与每坐标只保留一位的方式有何区别？',[17],'标量桶受校准数据影响；二值量化每坐标一位。'),
('training','只拿到一个很小的 LoRA adapter，就能不依赖原模型部署吗？',[19],'不能，部署还需要基座模型。'),
('preferences','偏好训练中的 chosen/rejected 标签互相矛盾，会带来什么问题？',[20],'偏好对决定学习信号，矛盾或缺乏依据的偏好会教出不良行为。'),
('decoding','使用较便宜的小模型起草 token，是在给目标模型训练新知识吗？',[21],'不是；目标模型检查草稿，旨在减少顺序执行的目标模型步骤。'),
('calibration','评估安全行为时，为什么不能只追求更高的拒绝率？',[24],'需要同时评估有害服从和对正常请求的误拒。'),
('uncertainty','如果错误答案与放弃回答都得零分，评测规则可能鼓励什么行为？',[25],'不确定时猜测，因此应区分正确、无支持错误和适当不确定。'),
('benchmark_scope','短事实问答得分很高，是否就能说明长篇多论断回答也可靠？',[26],'不能，短问题的事实性评测不直接证明长篇可靠性。'),
]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--notes-dir',type=Path,default=Path('example_notes'))
    args=p.parse_args();root=args.output
    root.mkdir(parents=True,exist_ok=False);corpus=root/'corpus';corpus.mkdir()
    for note in args.notes_dir.glob('*.md'):shutil.copyfile(note,corpus/note.name)
    synthetic=set()
    # All names and facts are deliberately fictional, not production policy.
    for i in range(1,7):
        documents={
            f'pilot_service_{i}.md':f'# Fictional service F{i}\n\nSynthetic evaluation fixture. Service F{i} delegates its retention policy to pilot_policy_{i}.md. The archived policy is not current.\n',
            f'pilot_policy_{i}.md':f'# Current fictional policy P{i}\n\nSynthetic evaluation fixture. The current retention period is {20+i} days. For incident records, the exception is {2+i} days. Both rules apply only to the service that links to this policy.\n',
            f'pilot_archive_{i}.md':f'# Archived fictional policy F{i}\n\nSynthetic evaluation distractor. Service F{i} used to keep all records for {80+i} days. This archived edition has been superseded and must not be used as the current policy.\n'}
        for name,body in documents.items():
            (corpus/name).write_text(body);synthetic.add(name)
    notes={n.source:n for n in load_notes(corpus)}
    def source(number):return next(s for s in notes if s.startswith(f'{number:02d}_'))
    evidence={};cases=[];qrels=[]
    def anchor(name,section='core'):
        note=notes[name]
        if name in synthetic:
            start=0;end=len(note.content)
        else:
            heading='## Core idea' if section=='core' else '## Practical implication'
            start=note.content.index(heading)+len(heading)
            while note.content[start].isspace():start+=1
            end=note.content.find('\n\n## ',start)
            if end<0:end=len(note.content)
        quote=note.content[start:end]
        eid='e-'+hashlib.sha256(f'{name}:{start}:{end}'.encode()).hexdigest()[:16]
        evidence[eid]=dict(id=eid,source=name,document_revision=note.document_revision,
            start_char=start,end_char=end,quote=quote,quote_sha256=hashlib.sha256(quote.encode()).hexdigest(),
            annotation_status='provisional',reviewers=[])
        return eid
    def add(task,family,query,sources,fact,*,answerability='answerable',combine=False,section='core',extra=None):
        cid=f'pilot_{len(cases)+1:03d}'
        eids=[anchor(s,section) for s in sources]
        facets=([dict(id='joint-evidence',weight=1,critical=True,alternatives=[eids])] if combine
                else [dict(id=f'facet-{i+1}',weight=1,critical=True,alternatives=[[eid]]) for i,eid in enumerate(eids)])
        row=dict(id=cid,intent_family_id=family,task_type=task,query=query,query_language='zh',split='dev',
            answerability=answerability,query_origin='assistant_authored',annotation_status='provisional',reviewers=[],
            evidence_requirements=facets,required_facts=[fact] if fact else [],
            expected_behavior=fact or '明确说明知识库未提供所需事实，不编造。')
        if extra:row.update(extra)
        cases.append(row)
        for s in sources:qrels.append(dict(query_id=cid,source=s,grade=3,annotation_status='provisional',reviewers=[]))
        return row
    for task,seeds in [('semantic_discovery',SEMANTIC),('exploratory_retrieval',EXPLORE),('knowledge_qa',QA)]:
        for family,query,numbers,fact in seeds:
            # Full practical paragraph for questions that ask about an implication.
            section='practical' if task=='knowledge_qa' and numbers[0] in (12,13,14,15,19,20,24,25,26) else 'core'
            if task=='knowledge_qa' and numbers[0]==16:
                section='practical'
            add(task,family,query,[source(n) for n in numbers],fact,section=section)
    for i in range(1,7):
        add('multi_hop_qa','synthetic_retention_family',
            f'虚构服务 F{i} 当前普通记录与事件记录分别保留多久？沿服务说明查找现行规范，并排除旧版本。',
            [f'pilot_service_{i}.md',f'pilot_policy_{i}.md'],
            f'先确认服务所引用的现行规范：普通记录 {20+i} 天，事件记录 {2+i} 天；旧的 {80+i} 天不适用。',combine=True)
        qrels.append(dict(query_id=cases[-1]['id'],source=f'pilot_archive_{i}.md',grade=0,annotation_status='provisional',reviewers=[]))
    exacts=[('MCP',False,True,'content'),('LoRA',False,True,'content'),('prefixes',False,True,'content'),
            ('^1[67]_',True,True,'source'),('ARKB-PILOT-NO-SUCH-TOKEN-20260910',False,True,'content'),
            ('scalar quantization',False,False,'content')]
    for pattern,regex,sensitive,target in exacts:
        query=f'列出{ "文件名" if target=="source" else "正文" }中匹配 {pattern!r} 的所有笔记；使用{ "正则" if regex else "字面子串" }匹配，{ "区分" if sensitive else "不区分" }大小写。没有匹配请明确说明。'
        row=add('exact_lookup','exact_enumeration',query,[],'列出的文件集合必须与实际匹配完全一致。',
                extra={'exact_pattern':dict(query=pattern,regex=regex,case_sensitive=sensitive,target=target)})
        matched=[]
        for name,note in notes.items():
            text=name if target=='source' else note.content
            expression=pattern if regex else re.escape(pattern)
            hits=list(re.finditer(expression,text,flags=0 if sensitive else re.I))
            if hits:
                matched.append(name)
                qrels.append(dict(query_id=row['id'],source=name,grade=3,annotation_status='provisional',reviewers=[]))
        row['required_facts']=['匹配文件：'+(', '.join(sorted(matched)) if matched else '无')]
    for number,family,query,fact in [
        (10,'protocol','说明客户端与服务端的分工。','服务端暴露集成；AI 应用内客户端连接它。'),
        (19,'training','说明部署小 adapter 时是否还需要基座模型。','小 adapter 是增量，部署仍需基座。'),
        (25,'uncertainty','说明评测应如何区分猜测与适当的不确定。','区分正确、无支持错误和适当不确定。'),
        (17,'quantization','说明量化与减少维度是不是同一件事。','降低精度与减少维度不同。')]:
        name=source(number)
        add('direct_read',family,f'只读取 {name}，{query} 不要搜索。',[name],fact,
            section='core' if number==10 else 'practical',extra={'read_source':name})
    add('evidence_gap','missing_measurement','根据知识库，给出这个本地系统昨天测得的平均检索延迟，精确到毫秒。',[],
        '笔记没有提供本系统昨天的延迟测量，不能用一般性说明推算。',answerability='unanswerable')
    add('evidence_gap','missing_private_fact','知识库记录的虚构项目 ZX-NOT-RECORDED 的验收口令是什么？',[],
        '知识库没有这个项目或口令，明确无法确定。',answerability='unanswerable')
    add('evidence_gap','vectors','解释截短 embedding 维度后的归一化要求，并报告本系统截短后实际节省了百分之多少延迟。',[source(16)],
        '可以说明必要时重新归一化；本系统实测延迟节省比例未知，分开回答。',answerability='partial',section='practical')
    add('evidence_gap','ambiguous_version','请告诉我那个服务的新版保留期限。',[],
        '缺少服务身份，应询问具体服务，而不是任选 F1 到 F6。',answerability='needs_clarification')
    for family,query,answer in [
        ('provided_text','只按给出的数字计算：4 加 9 等于多少？','13'),
        ('provided_text','只处理给定列表，按字母排序：delta, alpha, gamma。','alpha, delta, gamma'),
        ('provided_text','不查资料，把“延迟降低了”翻译成英文。','Latency decreased.'),
        ('provided_text','只按这段话回答：方案甲用 2 秒，方案乙用 5 秒。哪个更快？','方案甲')]:
        add('no_retrieval',family,query,[],answer,answerability='not_applicable')
    if len(cases)!=60:raise ValueError(f'Expected 60 cases, got {len(cases)}')
    # Two independent passages can provide the same candidate-boundary fact.
    # This pilot demonstrates an OR alternative without requiring both sources.
    candidate=next(c for c in cases if c['intent_family_id']=='candidate_limit')
    note=notes[source(40)];heading='## Improve candidate coverage before reranking'
    start=note.content.index(heading)+len(heading)
    while note.content[start].isspace():start+=1
    end=note.content.index('\n\n## ',start);quote=note.content[start:end];eid='e-candidate-alternative'
    evidence[eid]=dict(id=eid,source=note.source,document_revision=note.document_revision,start_char=start,end_char=end,
        quote=quote,quote_sha256=hashlib.sha256(quote.encode()).hexdigest(),annotation_status='provisional',reviewers=[])
    candidate['evidence_requirements'][0]['alternatives'].append([eid])
    qrels.append(dict(query_id=candidate['id'],source=note.source,grade=3,annotation_status='provisional',reviewers=[]))
    for name,rows in [('queries.jsonl',cases),('evidence.jsonl',list(evidence.values())),('qrels.jsonl',qrels)]:
        (root/name).write_text(''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in rows))
    manifest=dict(schema_version=SCHEMA,corpus_id='arkb-pilot-20260910',
        description='Provisional development set. 40 existing authored notes and 18 synthetic fixtures; not traffic or independent human gold.',
        files={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['queries.jsonl','evidence.jsonl','qrels.jsonl']},
        corpus=[dict(source=n.source,document_revision=n.document_revision,body_sha256=hashlib.sha256(n.content.encode()).hexdigest(),
                     origin='synthetic_fixture' if n.source in synthetic else 'existing_authored_example') for n in notes.values()])
    (root/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    dataset=load_dataset(root,notes_dir=corpus,allow_provisional=True)
    (root/'validation.json').write_text(json.dumps(dataset_report(dataset),ensure_ascii=False,indent=2)+'\n')
    lines=['# Pilot annotation review packet','','All cases are provisional and dev-only. No human review is claimed.',
           'Record accepted/changed/rejected, reviewer identity and rationale; update manifest hashes after adjudication.','']
    for case in cases:
        lines += [f'## {case["id"]}: {case["task_type"]}', '',case['query'],'',
                  f'Family: `{case["intent_family_id"]}`; answerability: `{case["answerability"]}`.',
                  '',f'Draft criterion: {case["expected_behavior"]}', '']
        for facet in case['evidence_requirements']:
            lines += [f'Facet `{facet["id"]}` — alternatives are OR; evidence within each is AND.','']
            for alt in facet['alternatives']:
                for eid in alt:
                    e=evidence[eid]
                    lines += [f'- `{eid}`: [{e["source"]}](corpus/{e["source"]}) body [{e["start_char"]}, {e["end_char"]})','',
                              '> '+e['quote'].replace('\n','\n> '),'']
        lines += ['Review: **pending**.','']
    (root/'review.md').write_text('\n'.join(lines))
    print(json.dumps(dataset_report(dataset),ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
