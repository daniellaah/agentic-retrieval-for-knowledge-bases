import json
from unittest.mock import Mock, call

from ollama import ResponseError
import pytest

from arkb.agent import AgentState, AgentTools, TOOL_DEFINITIONS, run_agent
from arkb.agent.loop import SYSTEM_INSTRUCTION
from arkb.knowledge.models import Chunk, ChunkRecord, Note
from arkb.retrieval import BM25Retriever, ExactRetriever, RetrievalEngine
from tests.agent.helpers import ScriptedModel, reply, tool_call


@pytest.fixture
def bm25_tools(documents):
    engine = RetrievalEngine(bm25=BM25Retriever(list(documents.records()), index_id='test'))
    return AgentTools(documents=documents, exact=ExactRetriever(documents), engine=engine, mode='bm25')


@pytest.mark.parametrize('query,call,observation', [
    ('哪些笔记提到了 RAG', tool_call('match', query='RAG'),
     {'query': 'RAG', 'results': [{'source': 'rag.md', 'content': 'RAG'}]}),
    ('有哪些笔记和 RAG 相关', tool_call('search', query='RAG'),
     {'query': 'RAG', 'results': [{'source': 'retrieval.md', 'content': '相关知识'}]}),
    ('读取 rag.md', tool_call('read', source='rag.md'),
     {'result': {'source': 'rag.md', 'content': '完整文档内容'}}),
])
def test_model_selected_tool_receives_arguments_and_returns_observation(query, call, observation):
    tools = Mock(spec=AgentTools, tool_definitions=Mock(return_value=TOOL_DEFINITIONS))
    name = call['function']['name']
    getattr(tools, name).return_value = observation
    final = reply('  model response\n')

    def after_tool(messages):
        assert messages[1] == {'role': 'user', 'content': query}
        assert messages[-2]['tool_calls'] == [call]
        assert messages[-1]['role'] == 'tool'
        assert messages[-1]['tool_name'] == name
        assert json.loads(messages[-1]['content']) == observation
        return final

    model = ScriptedModel(reply(calls=[call]), after_tool)
    result = run_agent(query, client=model, tools=tools, model='fake')
    assert result.stop_reason == 'final'
    assert result.response == final.message.content
    assert result.state.turn == 2
    assert result.state.tool_calls == [call]
    getattr(tools, name).assert_called_once_with(**call['function']['arguments'])
    for other in {'match', 'search', 'read'} - {name}:
        getattr(tools, other).assert_not_called()
    assert len(model.requests[0]['messages']) == 2
    for request in model.requests:
        assert request['model'] == 'fake'
        assert request['stream'] is False
        assert request['think'] is True
        assert request['messages'][0] == {'role': 'system', 'content': SYSTEM_INSTRUCTION}
        assert [d['function']['name'] for d in request['tools']] == ['match', 'search', 'read']
        assert all(d['type'] == 'function' for d in request['tools'])
        assert set(request['tools'][1]['function']['parameters']['properties']) == {'query', 'source', 'limit', 'mode'}


def test_ordinary_input_can_finish_without_tools(tools, engine):
    final = reply('你好！')
    model = ScriptedModel(final)
    result = run_agent('你好', client=model, tools=tools, model='fake', max_turns=1)
    assert result.response == final.message.content
    assert result.stop_reason == 'final'
    assert result.state.turn == 1
    assert result.state.tool_calls == []
    assert [m['role'] for m in result.state.messages] == ['system', 'user', 'assistant']
    engine.search.assert_not_called()


@pytest.mark.parametrize('think', [True, False])
def test_think_is_forwarded_on_every_turn_without_changing_loop_semantics(tools, think):
    first = reply(calls=[tool_call('read', source='a.md')])
    first.message.thinking = 'Provider reasoning accompanying the tool call.'
    final = reply('Final response')
    final.message.thinking = 'Provider reasoning accompanying the final answer.'
    model = ScriptedModel(first, final)
    result = run_agent('Read a.md', client=model, tools=tools, model='fake', think=think)
    assert result.response == 'Final response' and result.state.turn == 2
    assert result.stop_reason == 'final'
    assert all(request['think'] is think for request in model.requests)
    assert result.state.messages[2]['thinking'] == first.message.thinking
    assert result.state.messages[3]['role'] == 'tool'


def test_thinking_alone_is_not_a_final_response(tools):
    response = reply()
    response.message.thinking = 'Still considering what to do.'
    with pytest.raises(ValueError, match='neither tool calls nor a final response'):
        run_agent('Question', client=ScriptedModel(response), tools=tools, model='fake', think=True)


def test_multiple_calls_in_one_turn_preserve_order_and_are_all_observed(tools):
    calls = [tool_call('match', query='foo()'), tool_call('read', source='a.md'),
             tool_call('read', source='b.md')]

    def after_batch(messages):
        assert messages[2]['content']  # Text accompanying calls is not a final answer.
        assert messages[2]['tool_calls'] == calls
        assert [m['tool_name'] for m in messages[3:]] == ['match', 'read', 'read']
        assert json.loads(messages[4]['content'])['result']['source'] == 'a.md'
        assert json.loads(messages[5]['content'])['result']['source'] == 'b.md'
        return reply('complete')

    model = ScriptedModel(reply('Inspecting documents', calls=calls), after_batch)
    result = run_agent('Read matching notes', client=model, tools=tools, model='fake')
    assert result.stop_reason == 'final'
    assert result.state.turn == 2
    assert result.state.tool_calls == calls


@pytest.mark.parametrize('max_turns', [1, 3, 4])
def test_repeated_calls_stop_at_exact_turn_limit_without_an_extra_model_request(tools, max_turns):
    call = tool_call('search', query='question')
    model = Mock()
    model.chat.return_value = reply('Still searching', calls=[call])
    result = run_agent('question', client=model, tools=tools, model='fake', max_turns=max_turns)
    assert result.stop_reason == 'max_turns'
    assert result.response is None
    assert result.state.turn == model.chat.call_count == max_turns
    assert result.state.tool_calls == [call] * max_turns
    assert len([m for m in result.state.messages if m['role'] == 'tool']) == max_turns
    assert result.state.messages[-1]['role'] == 'tool'


def test_empty_results_remain_observations_and_allow_a_followup(tools):
    def broaden(messages):
        assert json.loads(messages[-1]['content'])['results'] == []
        return reply(calls=[tool_call('match', query='foo()')])

    model = ScriptedModel(reply(calls=[tool_call('search', query='missing')]), broaden, reply('done'))
    result = run_agent('Find notes', client=model, tools=tools, model='fake')
    assert result.stop_reason == 'final'
    assert [c['function']['name'] for c in result.state.tool_calls] == ['search', 'match']


def test_repeated_search_evidence_is_reported_without_blocking_a_known_source(bm25_tools):
    def after_repeated_search(messages):
        observations = [m for m in messages if m['role'] == 'tool']
        first, second, third = [json.loads(m['content']) for m in observations]
        assert len({first['query'], second['query'], third['query']}) == 3
        assert first['results'] and second['results'] and third['results']
        assert all(hit in first['results'] for response in (second, third) for hit in response['results'])
        assert messages[-1]['role'] == 'system'
        assert 'no new evidence' in messages[-1]['content']
        return reply(calls=[tool_call('read', source='a.md')])

    def after_read(messages):
        assert messages[-1]['tool_name'] == 'read'
        assert json.loads(messages[-1]['content'])['result']['source'] == 'a.md'
        assert len([m for m in messages if m['role'] == 'system']) == 2
        return reply('  final from the model\n')

    model = ScriptedModel(reply(calls=[tool_call('search', query='foo')]),
                          reply(calls=[tool_call('search', query='foo rare')]),
                          reply(calls=[tool_call('search', query='foo idea')]),
                          after_repeated_search, after_read)
    result = run_agent('Find material, then read the relevant source', client=model,
                       tools=bm25_tools, model='fake', max_turns=5)
    assert result.response == '  final from the model\n'
    assert result.stop_reason == 'final' and result.state.turn == 5
    assert model.requests[2]['messages'][-1]['role'] == 'tool'
    assert [call.name for call in result.trace.tool_calls] == ['search', 'search', 'search', 'read']
    assert all(call.result is not None for call in result.trace.tool_calls)
    assert all(request['tools'] == model.requests[0]['tools'] for request in model.requests)


@pytest.mark.parametrize('first,followups,stalled', [
    ({'query': 'missing'}, [{'query': 'also_missing'}], True),
    ({'query': 'missing'}, [{'query': 'foo'}], False),
    ({'query': 'foo'}, [{'query': 'missing'}], True),
    ({'query': 'foo'}, [{'query': 'foo', 'source': 'a.md'}], True),
    ({'query': 'foo', 'source': 'a.md'}, [
        {'query': 'foo', 'source': 'b.md'}, {'query': 'foo', 'source': 'a.md'}], False),
])
def test_search_progress_accounts_for_empty_results_and_the_entire_turn(bm25_tools, first, followups, stalled):
    model = ScriptedModel(reply(calls=[tool_call('search', **first)]),
                          reply(calls=[tool_call('search', **first)]),
                          reply(calls=[tool_call('search', **options) for options in followups]),
                          reply('finished'))
    result = run_agent('Find notes', client=model, tools=bm25_tools, model='fake', max_turns=4)
    # An empty first search can be reformulated. Later reminders never split a
    # batch of observations or overlook new evidence from an earlier batch call.
    assert model.requests[1]['messages'][-1]['role'] == 'tool'
    assert model.requests[2]['messages'][-1]['role'] == 'tool'
    assert (model.requests[3]['messages'][-1]['role'] == 'system') is stalled
    assert result.response == 'finished' and result.state.turn == 4
    assert len(result.trace.tool_calls) == 2 + len(followups)
    assert all(call.result is not None for call in result.trace.tool_calls)


def test_new_chunk_in_a_known_source_is_search_progress(documents):
    note = Note('Facts', 'alpha\nbeta', 'a.md')
    chunks = [Chunk('alpha', note.title, note.source, 0, 0, 5),
              Chunk('beta', note.title, note.source, 1, 6, 10)]
    records = [ChunkRecord.from_note(chunk, note=note, vault_id='v') for chunk in chunks]
    engine = RetrievalEngine(bm25=BM25Retriever(records, index_id='test'))
    tools = AgentTools(documents=documents, exact=ExactRetriever(documents), engine=engine, mode='bm25')
    model = ScriptedModel(reply(calls=[tool_call('search', query='alpha')]),
                          reply(calls=[tool_call('search', query='alpha')]),
                          reply(calls=[tool_call('search', query='beta')]), reply('both facts'))
    result = run_agent('Find both facts', client=model, tools=tools, model='fake', max_turns=4)
    assert [call.result['results'][0]['content'] for call in result.trace.tool_calls] == ['alpha', 'alpha', 'beta']
    assert all(m['role'] != 'system' for m in model.requests[3]['messages'][1:])
    assert result.response == 'both facts'


def test_runs_have_independent_conversations(tools):
    model = ScriptedModel(reply(calls=[tool_call('read', source='a.md')]), reply('first'), reply('second'))
    first = run_agent('Read a.md', client=model, tools=tools, model='fake')
    second = run_agent('Hello', client=model, tools=tools, model='fake')
    assert first.state is not second.state
    assert first.state.turn == 2 and second.state.turn == 1
    assert second.state.tool_calls == []
    assert [m['role'] for m in model.requests[2]['messages']] == ['system', 'user']
    left, right = AgentState(), AgentState()
    left.messages.append({'role': 'user', 'content': 'left'})
    assert right.messages == []


@pytest.mark.parametrize('options', [
    {'query': ''}, {'query': ' '}, {'query': None}, {'model': ''}, {'model': None},
    {'max_turns': 0}, {'max_turns': -1}, {'max_turns': True}, {'max_turns': 1.5},
    {'think': None}, {'think': 'false'}, {'think': 0}, {'think': 1},
])
def test_invalid_run_options_fail_before_model_or_tools(options):
    client, tools = Mock(), Mock(spec=AgentTools, tool_definitions=Mock(return_value=TOOL_DEFINITIONS))
    with pytest.raises(ValueError):
        run_agent(client=client, tools=tools, **{'query': 'x', 'model': 'fake', **options})
    client.chat.assert_not_called()
    assert tools.mock_calls == []


@pytest.mark.parametrize('name', ['bm25', 'semantic', 'hybrid', 'rrf', 'rerank', '_documents', '__init__', 'tool_definitions'])
def test_only_public_tools_can_be_dispatched(name):
    tools = Mock(spec=AgentTools, tool_definitions=Mock(return_value=TOOL_DEFINITIONS))
    model = ScriptedModel(reply(calls=[tool_call(name, query='x')]))
    with pytest.raises(ValueError, match='Unknown agent tool'):
        run_agent('x', client=model, tools=tools, model='fake')
    assert tools.mock_calls == [call.tool_definitions()]


@pytest.mark.parametrize('call,error_type', [
    (tool_call('search'), TypeError),
    (tool_call('search', query='x', mode='unknown'), ValueError),
    (tool_call('search', query='x', limit=True), ValueError),
    (tool_call('match', query='[', regex=True), ValueError),
    (tool_call('read', source='absent.md'), LookupError),
    (tool_call('read', source='a.md', document_id='0' * 64), LookupError),
])
def test_invalid_calls_propagate_without_followup_or_fake_success(tools, call, error_type):
    model = ScriptedModel(reply(calls=[call]))
    with pytest.raises(error_type):
        run_agent('x', client=model, tools=tools, model='fake')
    assert len(model.requests) == 1


@pytest.mark.parametrize('error', [ConnectionError('model offline'), ResponseError('failed', 503)])
def test_model_errors_propagate_unchanged(tools, error):
    client = Mock()
    client.chat.side_effect = error
    with pytest.raises(type(error)) as raised:
        run_agent('x', client=client, tools=tools, model='fake')
    assert raised.value is error
    assert client.chat.call_count == 1


def test_backend_errors_propagate_unchanged(tools, engine):
    error = RuntimeError('backend unavailable')
    engine.search.side_effect = error
    model = ScriptedModel(reply(calls=[tool_call('search', query='x')]))
    with pytest.raises(RuntimeError) as raised:
        run_agent('x', client=model, tools=tools, model='fake')
    assert raised.value is error
    assert len(model.requests) == 1


@pytest.mark.parametrize('response,pattern', [
    (reply(), 'neither tool calls nor a final response'),
    (reply('  '), 'neither tool calls nor a final response'),
    (reply('partial', done_reason='length'), 'truncated'),
    (reply(calls=[tool_call('read', source='a.md')], done_reason='length'), 'truncated'),
])
def test_empty_or_truncated_responses_are_not_successful_finals(response, pattern):
    tools = Mock(spec=AgentTools, tool_definitions=Mock(return_value=TOOL_DEFINITIONS))
    with pytest.raises(ValueError, match=pattern):
        run_agent('x', client=ScriptedModel(response), tools=tools, model='fake')
    assert tools.mock_calls == [call.tool_definitions()]


def test_non_assistant_response_is_rejected(tools):
    response = reply('invalid role')
    response.message.role = 'user'
    with pytest.raises(ValueError, match='assistant message'):
        run_agent('x', client=ScriptedModel(response), tools=tools, model='fake')
