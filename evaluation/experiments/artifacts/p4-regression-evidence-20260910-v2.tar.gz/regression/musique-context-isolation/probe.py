import importlib.util,json
from contextlib import ExitStack
from dataclasses import asdict
from pathlib import Path
from arkb.config import RuntimeConfig
from arkb.runtime import Runtime
from arkb.knowledge.sqlite import SQLiteStorage
from arkb.evaluation.external import ExternalDataset,digest,write_json
script=Path('evaluation/experiments/run_p4_agents.py').resolve()
spec=importlib.util.spec_from_file_location('p4_runner',script);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
root=Path('evaluation/results/p4-regression/musique-context-isolation');root.mkdir(exist_ok=False)
checks=[];engines=[];sources=[];builds=[]
with ExitStack() as stack,Runtime(RuntimeConfig(offline=True,tokenizer_cache=Path('.uv-cache/tokenizers').resolve(),qdrant_url='http://127.0.0.1:32776')) as runtime:
 for i,label in enumerate(('alpha','omega')):
  corpus=[{'id':str(j),'title':f'{label} {j}','text':f'commonprobe {label} isolated context document number {j}.'} for j in range(2)]
  data=ExternalDataset(f'musique-{i}',corpus,{'q':'commonprobe'},{'q':{}},{},{})
  directory=root/'contexts'/str(i);data.materialize(directory)
  db,build,elapsed=module.index_musique_context(runtime,root,i,directory)
  storage=stack.enter_context(SQLiteStorage(db,read_only=True))
  engine=runtime.retrieval_engine(storage,build.manifest,modes=('bm25','semantic'),exact=True)
  expected=set(data.source_map());sources.append(expected);engines.append(engine);builds.append(asdict(build))
  assert build.manifest.document_count==2 and build.manifest.chunk_count==2
  for mode in ('bm25','semantic'):
   hits=engine.search('commonprobe',mode=mode,top_k=10)
   assert {h.source for h in hits.results}==expected
   assert hits.index_id==build.manifest.index_version
   checks.append(f'context_{i}_{mode}_only_registered_sources')
 assert not sources[0]&sources[1]
 assert builds[0]['manifest']['index_version']!=builds[1]['manifest']['index_version']
 for i,engine in enumerate(engines):
  assert {h.source for h in engine.search('commonprobe',mode='semantic',top_k=10).results}==sources[i]
  checks.append(f'context_{i}_remains_isolated_after_both_builds')
write_json(Path('evaluation/audits/20260910-p4-musique-context-isolation.json'),{'passed':True,'checks':checks,'builds':builds,'runner_sha256':digest(script),'probe_sha256':digest(Path(__file__)),'scope':'Two synthetic contexts, two real Ollama/SQLite/Qdrant indexes using the exact runner helper. No Agent or benchmark score was produced.','release_eligible':False})
(root/'probe.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'passed':True,'checks':len(checks)}))
